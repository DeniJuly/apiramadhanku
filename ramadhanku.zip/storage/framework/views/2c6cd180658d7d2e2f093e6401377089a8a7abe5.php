<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <title>Saran</title>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10 col-md-10 mt-3">
                <table class="table table-hover table-stripped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>Id</th>
                            <th>Nama</th>
                            <th>Saran</th>
                            <th>Foto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $saran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($s->id); ?></td>
                            <td><?php echo e($s->nama); ?></td>
                            <td><?php echo e($s->isi); ?></td>
                            <td>
                                <?php if($s->foto): ?>
                                <a href="<?php echo e(asset('img/saran/' . $s->foto)); ?>">
                                    <img src="<?php echo e(asset('img/saran/' . $s->foto)); ?>" width="100px">
                                </a>
                                <?php else: ?> 
                                 tidak ada
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($saran->links()); ?>

            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\ramadhanku\resources\views/saran.blade.php ENDPATH**/ ?>